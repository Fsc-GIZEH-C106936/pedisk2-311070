Parts List
----------

| Reference      | Part               |
|----------------|--------------------|
| C1-11          | 0.1 uF             |
| J1             | 34-pin Header      |
| Q1             | 2N2222 (??)        |
| R1, R2, R3, R7 | 3.3 K              |
| R4, R5, R6     | 150 Ohm            |
| RN1            | 4.7 K              |
| U1             | 74LS00             |
| U2             | 74LS32             |
| U3             | 74LS139            |
| U4             | 2716               |
| U5             | WD1793             |
| U6             | 74LS74             |
| U7             | 74LS175            |
| U8             | 74367              |
| U9             | 901474-03          |
| U10            | 74LS14             |
| U11            | 7416               |
| U12            | 74LS161            |
| U13            | 74LS74             |
| W1, W2         | 3-pin Jumper Block |
| W3, W4, W5     | 2-pin Jumper Block |

